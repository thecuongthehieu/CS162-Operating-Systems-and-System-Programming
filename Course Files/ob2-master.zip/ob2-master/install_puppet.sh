#!/usr/bin/env bash
apt update
apt -y install puppet
