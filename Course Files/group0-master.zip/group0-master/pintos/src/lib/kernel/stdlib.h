#ifndef __LIB_KERNEL_STDLIB_H
#define __LIB_KERNEL_STDLIB_H

#endif /* lib/kernel/stdlib.h */
